public class Monkey extends RescueAnimal {

    private String species;
    private String tailLength;
    private String height;
    private String bodyLength;

    //Monkey species eligible for training: Capuchin, Guenon, Macaque, Marmoset, Squirrel monkey, Tamarin

    public Monkey(String name, String species, String tailLength, String height, String bodyLength, String gender, String age, String weight, String acquisitionDate, String acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry){

        setName(name);
        setSpecies(species);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);


    }

    public void setSpecies(String species){

        this.species = species;

    }
    public String getSpecies(){

        return species;

    }

    public void setTailLength(String tailLength){

        this.tailLength = tailLength;

    }

    public String getTailLength(){

        return tailLength;

    }

    public void setHeight(String height){

        this.height = height;

    }

    public String getHeight(){

        return height;

    }

    public void setBodyLength(String bodyLength){

        this.bodyLength = bodyLength;

    }

    public String getBodyLength(){

        return bodyLength;

    }



}
