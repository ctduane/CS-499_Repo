import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {


        initializeDogList();
        initializeMonkeyList();
        String userInput = " ";
        Scanner sc = new Scanner(System.in);

        //Christopher Duane
        //IT-145

        //The loop I created uses a do-while loop so that displayMenu will always be called at least once. Then the
        //user's input is taken, and their input is compared to the available menu options. Methods are then called
        //based on which option the user chooses. The program will loop again if anything aside from the menu options
        //or q is entered, and the program quits entirely if the user enters q.
        do{
            displayMenu();
            userInput = sc.nextLine();

            if (userInput.equals("1")){
                System.out.println("You chose option 1, to intake a new dog.");
                System.out.println();
                intakeNewDog(sc);

            }else if (userInput.equals("2")){
                System.out.println("You chose option 2, to intake a new monkey.");
                System.out.println();
                intakeNewMonkey(sc);

            }else if (userInput.equals("3")){
                System.out.println("You chose option 3, to reserve an animal.");
                System.out.println();
                reserveAnimal(sc);

            }else if (userInput.equals("4")){
                System.out.println("You chose option 4, to print a list of all dogs.");
                System.out.println();
                printAnimals("dog");

            }else if (userInput.equals("5")){
                System.out.println("You chose option 5, to print a list of all monkeys.");
                System.out.println();
                printAnimals("monkey");

            }else if (userInput.equals("6")){
                System.out.println("You chose option 6, to print a list of all animals that are not reserved.");
                System.out.println();
                printAnimals("available");

            }else if (userInput.equals("q")){
                System.out.println("You chose to quit the program.");

            }else{
                System.out.println("You did not choose a valid menu option.");
                System.out.println();

            }

        }while(!userInput.equals("q"));


    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");
        Dog dog4 = new Dog("Bea","Basset Hound","female","6","40","2/5/22","United States","in service", false,"Japan");
        Dog dog5 = new Dog("Snowy","White Fox Terrier","male","93","20","1929","Belgium","in service", false,"United States");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
        dogList.add(dog4);
        dogList.add(dog5);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {

        Monkey curiousGeorge = new Monkey("George","Macaque","1","3","3","male","2","20",
                "1941","Africa","in service", false,"United States");

        Monkey monkeyPrime = new Monkey("Monkey Prime","Squirrel Monkey","2","4","3","female","5","25",
                "2017","United States","Phase I", false,"Japan");

        Monkey rafiki = new Monkey("Rafiki","Squirrel Monkey","2","4","3","female","5","25",
                "2017","United States","in service", false,"Japan");

        Monkey chimChim = new Monkey("Chim Chim","Squirrel Monkey","2","4","3","female","5","25",
                "2017","United States","Phase I", false,"Japan");

        Monkey kingLouie = new Monkey("King Louie","Squirrel Monkey","2","4","3","female","5","25",
                "2017","United States","Phase I", false,"Japan");

        Monkey mojoJojo = new Monkey("Mojo Jojo","Squirrel Monkey","2","4","3","female","5","25",
                "2017","United States","Phase I", false,"Japan");

        Monkey abu = new Monkey("Abu","Squirrel Monkey","2","4","3","male","5","25",
                "2017","Agrabah","in service", false,"Japan");

        monkeyList.add(curiousGeorge);
        monkeyList.add(monkeyPrime);
        monkeyList.add(rafiki);
        monkeyList.add(chimChim);
        monkeyList.add(kingLouie);
        monkeyList.add(mojoJojo);
        monkeyList.add(abu);

    }


    //Since the code to check whether or not the dog is a duplicate was already given, all I had to change was
    //creating a new Dog object using the user's input.
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, inServiceCountry;
        name = scanner.nextLine();

        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }

        //Gather the rest of the dog's information.
        System.out.println("Enter the dog's breed: ");
        breed = scanner.nextLine();
        System.out.println("Enter the dog's gender: ");
        gender = scanner.nextLine();
        System.out.println("Enter the dog's age: ");
        age = scanner.nextLine();
        System.out.println("Enter the dog's weight: ");
        weight = scanner.nextLine();
        System.out.println("Enter today's date: ");
        acquisitionDate = scanner.nextLine();
        System.out.println("Enter the country of acquisition: ");
        acquisitionCountry = scanner.nextLine();
        inServiceCountry = acquisitionCountry;

        //Create a new dog with the provided information.
        dogList.add(new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, "intake", false, inServiceCountry));

    }


        //Currently the code for the intakeNewMonkey method is pretty messy, I know there are probably much better ways
        //of doing this. It declares String values that will be used to create a new Monkey at the end of the method.

        //It then prompts the user for the monkey's name to make sure there aren't any duplicates, and checks the
        //species to make sure it matches one of the eligible species.

        //After all of the information is collected from the user, a new Monkey object is created using the given
        //information.
        public static void intakeNewMonkey(Scanner scanner) {

            //Create string variables that will be used to construct a new Monkey object at the end.
            String name, species, tailLength, height, bodyLength, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, inServiceCountry;

            //Gather monkey's name from user input and set trainingStatus to intake.
            System.out.println("What is the monkey's name?");
            name = scanner.nextLine();
            trainingStatus = "intake";

            //Created an ArrayList of Strings that has all of the eligible species types.
            ArrayList<String> speciesList = new ArrayList<String>(6);
            speciesList.add("tamarin"); speciesList.add("capuchin"); speciesList.add("macaque"); speciesList.add("marmoset"); speciesList.add("squirrel monkey"); speciesList.add("guenon");

            //Compare's the user's name input to monkeys in the monkeyList to see if it is already in the system.
            for(Monkey monkey: monkeyList){
                if (monkey.getName().equalsIgnoreCase(name)){
                    System.out.println("This monkey is already in our system.");
                    return;

                }
            }

            //Gather monkey species from user's input.
            System.out.println("What is the monkey's species?");
            species = scanner.nextLine();

            //Checks the previously declared speciesList ArrayList to see if the user's input matches one of the
            //eligible monkey types. Sets the user's input to all lowercase to prevent capitalization from affecting the outcome.
            if (speciesList.contains(species.toLowerCase())){
                System.out.println("You entered: "+species+"."+" This is an eligible species.");
            }else{
                System.out.println("You entered: "+species+"."+" This monkey cannot be entered because it is not an eligible species.");
                return;
            }

            //Gather the rest of the monkey's information.
            System.out.println("Enter the monkey's tail length: ");
            tailLength = scanner.nextLine();
            System.out.println("Enter the monkey's height: ");
            height = scanner.nextLine();
            System.out.println("Enter the monkey's body length: ");
            bodyLength = scanner.nextLine();
            System.out.println("Enter the monkey's gender: ");
            gender = scanner.nextLine();
            System.out.println("Enter the monkey's age: ");
            age = scanner.nextLine();
            System.out.println("Enter the monkey's weight: ");
            weight = scanner.nextLine();
            System.out.println("Enter today's date: ");
            acquisitionDate = scanner.nextLine();
            System.out.println("Enter the country of acquisition: ");
            acquisitionCountry = scanner.nextLine();
            inServiceCountry = acquisitionCountry;

            //Create a new Monkey object using the provided information.
            monkeyList.add(new Monkey(name, species, tailLength, height, bodyLength, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, false, inServiceCountry));









        }

        //reserveAnimal method prompts the user for input, specifically the type of animal they're looking for and
        //the country they need the animal in. Then it checks the location and reservation status of all animals in the
        //specified animal's list, and prints the names of those that are eligible. The user is then prompted
        //to enter the name of the animal they wish to reserve, and that animal's reservation status is changed.
        public static void reserveAnimal(Scanner scanner) {

            String name;
            String animalType;
            String userCountry;
            int i = 0;
            int c = 0;

            //Ask user which type of animal they are looking to reserve, then set animalType to be used later.
            System.out.println("Are you looking to reserve a dog or a monkey?");
            animalType = scanner.nextLine();

            //Ask user which country the animal will be needed in to narrow down available options later.
            System.out.println("Enter the country where the animal is needed: ");
            userCountry = scanner.nextLine();

            //If user answers "dog", a for loop will iterate through each dog in the dogList. If the dog is not reserved,
            //the service location matches the user's country, and the dog's training status is "in service", prints that (insert dog name)
            //is available to reserve in the provided country. The integer i is used to keep track of the number of dogs
            //that are available.
            if (animalType.equalsIgnoreCase("dog")){
                for (Dog dog: dogList){
                    if (!dog.getReserved() && dog.getInServiceLocation().equalsIgnoreCase(userCountry) && dog.getTrainingStatus().equalsIgnoreCase("in service")){
                        System.out.println(dog.getName()+" is available to reserve in your country.");
                        i += 1;
                    }
                }
                //if statement that checks the value of i (the number of dogs matching the critera). If i is not equal to
                //0, then it will ask which animal to reserve. If i is equal to 0, it will print that there are no
                //animals to reserve matching the user's critera.
                if (i != 0){
                    System.out.println("Which animal would you like to reserve?");
                }else if (i == 0){
                    System.out.println("There are no animals to reserve matching the given criteria.");
                    return;
                }
                //User enters the name of the dog from the list that they want to reserve. If the user entered one of the
                //names available, the dog's reservation status is set to true and the user is informed that the dog
                //has been successfully reserved. The variable c is used to keep track of whether or not a dog is
                //available. If the dog is successfully reserved, c is set to 0. If c is not equal to 0, it prints
                //that there are no dogs available in the user's country with that name.
                name = scanner.nextLine();
                for (Dog dog: dogList){
                    if (dog.getName().equalsIgnoreCase(name) && !dog.getReserved()){
                        dog.setReserved(true);
                        System.out.println(dog.getName()+" has been reserved successfully.");
                        c = 0;
                        break;
                    }else{
                        c+=1;
                    }
                }

                if (c!=0){
                    System.out.println("There are no dogs to reserve in your country with the name you entered.");
                }
            //Does practically the exact same thing as the dog version. If the user enters "monkey" then the for loop
            //iterates through the monkeyList and compares information. If the monkey is not reserved, is in service
            //in the user's country, and their training status is "in service", that monkey's name will be printed to
            //a list of available monkeys. i is used to keep track of the number of monkeys matching the critera.
            }else if (animalType.equalsIgnoreCase("monkey")){
                for (Monkey monkey: monkeyList){
                    if (!monkey.getReserved() && monkey.getInServiceLocation().equalsIgnoreCase(userCountry) && monkey.getTrainingStatus().equalsIgnoreCase("in service")){
                        System.out.println(monkey.getName()+" is available to reserve in your country.");
                        i += 1;
                    }
                }
                //checks the value of i (number of monkeys matching the criteria). If i is not equal to 0, then it will
                //ask which animal to reserve. If i is equal to 0, it will print that there are no animals to reserve
                //matching the user's criteria.
                if (i != 0){
                    System.out.println("Which animal would you like to reserve?");
                }else if (i == 0){
                    System.out.println("There are no animals to reserve matching the given criteria.");
                    return;
                }
                //Get the name of the monkey that the user want to reserve. If the user enters the name of a monkey that
                //is available, that Monkey object's reservation status is set to true. The variable c is used to keep
                //track of whether or not a monkey is available. If the monkey is successfully reserved, c is set to 0.
                //If c is not equal to 0, it prints that there are no monkeys with that name in the user's country.
                name = scanner.nextLine();
                for (Monkey monkey: monkeyList){
                    if (monkey.getName().equalsIgnoreCase(name) && !monkey.getReserved()){
                        monkey.setReserved(true);
                        System.out.println(monkey.getName()+" has been successfully reserved.");
                        c = 0;
                        break;
                    }else{
                        c+=1;
                    }
                }
                if (c!=0){
                    System.out.println("There are no monkeys to reserve in your country with the name you entered.");
                }
            }

        }

        //I currently have the printAnimals use the listType parameter to determine which branch of an if-statement to
        //go down which then simply retrieves the information for the animals using the getter methods, and prints
        //it out as a string.

        //The "available" branch checks the reservation status and makes sure the animal's training status is
        //"in service", then prints the animals matching the criteria for both dogs and monkeys.
        public static void printAnimals(String listType) {
            if (listType.equals("monkey")){
                for (Monkey monkey: monkeyList){
                    System.out.println("Name: " + monkey.getName() + " / Training status: " + monkey.getTrainingStatus() + " / Acquisition country: " + monkey.getAcquisitionLocation() + " / Reservation status: " + monkey.getReserved());

                }
            }else if (listType.equals("dog")){
                for (Dog dog: dogList){
                    System.out.println("Name: " + dog.getName() + " / Training status: " + dog.getTrainingStatus() + " / Acquisition country: " + dog.getAcquisitionLocation() + " / Reservation status: " + dog.getReserved());

                }
            }else if (listType.equals("available")){
                System.out.println("List of available monkeys: ");
                for (Monkey monkey: monkeyList){
                    if (!monkey.getReserved() && monkey.getTrainingStatus().equalsIgnoreCase("in service")){
                        System.out.println(monkey.getName());
                    }
                }
                System.out.println();
                System.out.println("List of available dogs: ");
                for (Dog dog: dogList){
                    if (!dog.getReserved() && dog.getTrainingStatus().equalsIgnoreCase("in service")){
                        System.out.println(dog.getName());
                    }
                }

            }else{
                System.out.println("Debugging is fun :)");
            }



        }
}

